import React from 'react';
import { Link } from 'react-router-dom';

/**
 * AuthLayout - Master modern layout shell for all FIZZ-CONNECT auth views.
 * Handles split-screen desktop, responsive mobile stacking, background,
 * branding header with navigation links, and bottom retro status tags.
 */
export default function AuthLayout({
  headline,
  highlightWord,
  subtext,
  bottomLeftTag,
  bottomRightTag,
  visualSlot,
  children,
  centeredLayout = false,
}) {
  return (
    <div className="auth-master-wrapper">
      {/* Background Pixel Grid & Atmospheric Ambient Radiance */}
      <div className="pixel-grid-bg" />

      {/* Floating ambient corner aqua glow */}
      <div className="ambient-glow glow-top-left" />
      <div className="ambient-glow glow-bottom-right" />

      {/* Top Header Navbar */}
      <header className="auth-header">
        <Link to="/login" className="brand-logo-link">
          {/* Pixel Gem / Cog Icon in Aqua theme */}
          <span className="pixel-brand-icon">
            <svg width="28" height="28" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
              <rect x="10" y="2" width="8" height="4" fill="#39D9D5" />
              <rect x="10" y="22" width="8" height="4" fill="#39D9D5" />
              <rect x="2" y="10" width="4" height="8" fill="#39D9D5" />
              <rect x="22" y="10" width="4" height="8" fill="#39D9D5" />
              <rect x="6" y="6" width="16" height="16" fill="#16C6D2" stroke="#39D9D5" strokeWidth="2" />
              <rect x="11" y="11" width="6" height="6" fill="#FFFFFF" />
            </svg>
          </span>

          <div className="brand-text-block">
            <h1 className="brand-title">
              <span className="brand-fizz">FIZZ-</span><span className="brand-connect">CONNECT</span>
            </h1>
            <span className="brand-tagline">PLAN · COLLABORATE · BUILD</span>
          </div>
        </Link>
      </header>

      {/* Main Content Area */}
      <main className={`auth-main-container ${centeredLayout ? 'layout-centered' : 'layout-split'}`}>
        {!centeredLayout ? (
          <>
            {/* Left Side: Editorial Typography & Pixel Collaboration Visual */}
            <section className="auth-left-section">
              <div className="editorial-text-group">
                <h2 className="editorial-headline">
                  {headline.map((line, idx) => (
                    <React.Fragment key={idx}>
                      {line}
                      <br />
                    </React.Fragment>
                  ))}
                  {highlightWord && <span className="text-red">{highlightWord}</span>}
                </h2>
                {subtext && <p className="editorial-subtext">{subtext}</p>}
              </div>

              {/* Pixel Visual Area */}
              <div className="visual-wrapper">{visualSlot}</div>
            </section>

            {/* Right Side: Auth Form Card */}
            <section className="auth-right-section">{children}</section>
          </>
        ) : (
          /* Centered Layout for Reset Success view */
          <section className="auth-center-section">
            <div className="center-visual-bg">{visualSlot}</div>
            <div className="center-card-wrapper">{children}</div>
          </section>
        )}
      </main>

      {/* Bottom Retro Status Tags - kept if passed, though mostly removed */}
      {(bottomLeftTag || bottomRightTag) && (
        <footer className="auth-footer-bar">
          <span className="footer-tag-left font-pixel">{bottomLeftTag}</span>
          <span className="footer-tag-right font-pixel">{bottomRightTag}</span>
        </footer>
      )}

      {/* Layout Styles */}
      <style>{`
        .auth-master-wrapper {
          position: relative;
          height: 100vh;
          min-height: 0;
          display: flex;
          flex-direction: column;
          padding: 20px 44px;
          box-sizing: border-box;
          z-index: 1;
          overflow: hidden;
        }

        .ambient-glow {
          position: fixed;
          width: 450px;
          height: 450px;
          border-radius: 50%;
          filter: blur(140px);
          pointer-events: none;
          z-index: 0;
          opacity: 0.35;
        }

        .glow-top-left {
          top: -100px;
          left: -100px;
          background: #DDF8F6;
        }

        .glow-bottom-right {
          bottom: -100px;
          right: -100px;
          background: #EFFCFB;
        }

        /* Header */
        .auth-header {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          position: relative;
          z-index: 10;
          flex-shrink: 0;
          padding-bottom: 12px;
        }

        .brand-logo-link {
          display: flex;
          align-items: center;
          gap: 14px;
          text-decoration: none;
        }

        .pixel-brand-icon {
          display: flex;
          align-items: center;
          filter: drop-shadow(0 0 10px rgba(22, 198, 210, 0.4));
          transition: transform 0.2s ease;
        }

        .brand-logo-link:hover .pixel-brand-icon {
          transform: scale(1.08) rotate(5deg);
        }

        .brand-text-block {
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        .brand-title {
          font-family: var(--font-sans);
          font-size: 24px;
          font-weight: 800;
          letter-spacing: -0.5px;
          line-height: 1;
        }

        .brand-fizz {
          color: var(--text-white); /* Dark Navy */
        }

        .brand-connect {
          color: var(--red-primary); /* Aqua */
        }

        .brand-tagline {
          font-family: var(--font-sans);
          font-size: 11px;
          color: var(--text-muted);
          letter-spacing: 0.5px;
          text-transform: uppercase;
        }

        /* Main Container */
        .auth-main-container {
          flex: 1;
          min-height: 0;
          display: flex;
          align-items: stretch;
          width: 100%;
          max-width: 1440px;
          margin: 0 auto;
          position: relative;
          z-index: 5;
          padding: 8px 0;
          overflow: hidden;
        }

        .layout-split {
          display: grid;
          grid-template-columns: 1.3fr 0.82fr;
          gap: 42px;
          align-items: center;
          width: 100%;
          min-height: 0;
        }

        .layout-centered {
          display: flex;
          align-items: center;
          justify-content: center;
          width: 100%;
          position: relative;
        }

        /* Left Side */
        .auth-left-section {
          display: flex;
          flex-direction: column;
          gap: 16px;
          position: relative;
          height: 100%;
          min-height: 0;
          overflow: hidden;
        }

        .editorial-text-group {
          flex-shrink: 0;
        }

        .editorial-headline {
          font-family: var(--font-sans);
          font-size: clamp(28px, 3.5vw, 54px);
          font-weight: 900;
          color: var(--text-white);
          line-height: 1.08;
          letter-spacing: -1.5px;
        }

        .editorial-subtext {
          font-family: var(--font-sans);
          font-size: 14px;
          color: var(--text-muted);
          max-width: 440px;
          line-height: 1.6;
          margin-top: 8px;
        }

        .visual-wrapper {
          position: relative;
          flex: 1;
          min-height: 0;
          overflow: hidden;
          display: flex;
          align-items: center;
        }

        /* Right Side */
        .auth-right-section {
          display: flex;
          justify-content: center;
          align-items: center;
          width: 100%;
          height: 100%;
          min-height: 0;
          overflow-y: auto;
          overflow-x: hidden;
          padding: 8px 0;
        }

        .auth-right-section::-webkit-scrollbar {
          width: 4px;
        }

        .center-card-wrapper {
          position: relative;
          z-index: 5;
          width: 100%;
          max-width: 440px;
        }

        .center-visual-bg {
          position: absolute;
          inset: 0;
          pointer-events: none;
          z-index: 1;
        }

        /* Bottom Status Tags */
        .auth-footer-bar {
          display: flex;
          align-items: center;
          justify-content: space-between;
          width: 100%;
          padding-top: 10px;
          font-size: 10px;
          color: var(--text-muted);
          letter-spacing: 1px;
          opacity: 0.65;
          user-select: none;
          flex-shrink: 0;
        }

        /* ── Responsive Breakpoints ── */

        /* Large desktop */
        @media (max-width: 1200px) {
          .auth-master-wrapper {
            padding: 18px 36px;
          }
          .layout-split {
            grid-template-columns: 1.2fr 0.9fr;
            gap: 32px;
          }
        }

        /* Tablet landscape / small desktop */
        @media (max-width: 1080px) {
          .layout-split {
            grid-template-columns: 1fr 1fr;
            gap: 28px;
          }
        }

        /* Tablet portrait */
        @media (max-width: 900px) {
          .auth-master-wrapper {
            padding: 16px 24px;
            height: auto;
            min-height: 100vh;
            overflow-y: auto;
          }
          .auth-main-container {
            overflow: visible;
          }
          .layout-split {
            grid-template-columns: 1fr;
            gap: 24px;
          }
          .auth-left-section {
            overflow: visible;
            height: auto;
            text-align: center;
            align-items: center;
          }
          .editorial-subtext {
            margin: 0 auto;
          }
          .visual-wrapper {
            max-height: 320px;
          }
          .auth-right-section {
            height: auto;
            overflow: visible;
          }
        }

        /* Mobile large */
        @media (max-width: 640px) {
          .auth-master-wrapper {
            padding: 14px 16px;
          }
          .auth-header {
            flex-direction: row;
            flex-wrap: wrap;
            gap: 10px;
          }
          .editorial-headline {
            font-size: clamp(24px, 7vw, 34px);
          }
          .visual-wrapper {
            max-height: 240px;
          }
          .auth-footer-bar {
            flex-direction: column;
            gap: 6px;
            text-align: center;
          }
        }

        /* Mobile small */
        @media (max-width: 420px) {
          .auth-master-wrapper {
            padding: 12px 14px;
          }
          .visual-wrapper {
            max-height: 180px;
          }
          .brand-title {
            font-size: 20px;
          }
          .header-nav {
            display: none;
          }
        }

        /* Height-constrained screens (short viewports / laptops) */
        @media (max-height: 700px) and (min-width: 901px) {
          .auth-master-wrapper {
            padding: 10px 44px;
          }
          .editorial-headline {
            font-size: clamp(22px, 2.8vw, 40px);
          }
          .editorial-subtext {
            font-size: 13px;
          }
          .visual-wrapper {
            max-height: 240px;
          }
          .auth-footer-bar {
            padding-top: 6px;
            font-size: 9px;
          }
          .auth-header {
            padding-bottom: 6px;
          }
        }

        @media (max-height: 600px) and (min-width: 901px) {
          .auth-master-wrapper {
            padding: 8px 40px;
          }
          .visual-wrapper {
            max-height: 180px;
          }
          .editorial-headline {
            font-size: clamp(20px, 2.5vw, 32px);
          }
          .editorial-subtext {
            display: none;
          }
        }
      `}</style>
    </div>
  );
}
